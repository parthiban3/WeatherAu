package co.weather.au

object Constants {
  val appName="WeatherSimulation"
  val executionMode="local"
  val inputFilePath="/home/HadoopUser/workspace/sparkexamples/Spark SQL/src/Resouces/WeatherDataAll/All.txt"
  val weatherDataTable="weatherData"
  val dateFormatZone="yyyy-MM-dd HH:mm:ss z"
  val ZoneGMTPlusTen="GMT+10"
  val ZoneGMTPlusNine="GMT+9:30"
  val dayStartInx:Int=8
  val dayEndInx:Int=10
  val monStartInx:Int=5
  val monEndInx:Int=7
  //val calcQuery:String="select round((AVG(MAXT)-32)/1.8,1),round((AVG(MINT)-32)/1.8,1),round(AVG(WDSP),1),round(AVG(MXSPD),1),MAX(PRCP) from t1 where MO="+months+" and DA="+days"
  //val calcQuery:String="select X.station from (select station,max(maxt),max(mint) from "+weatherDataTable+" where months='@' and days='@@' group by station) X"
  val locSyd:String="Sydney"
  val locTow:String="Townsville"
  val locAde:String="Adelaide"
  val locBris:String="Brisbane"
  val locMel:String="Melbourne"
  val posSyd:String="-33.86,151.21,39"
  val posTow:String="-19.25,146.81,16"
  val posAde:String="-34.92,138.62,48"
  val posBris:String="-27.46,153.02,28"
  val posMel:String="-37.83,144.98,7"
  var currDateTen:String = InputProcess.getCurrentDate(Constants.ZoneGMTPlusTen)
  var currDateNine:String = InputProcess.getCurrentDate(Constants.ZoneGMTPlusNine)
  val calcQuery:String="select X.station, case when X.station='"+locSyd+"' then '"+posSyd+"' when X.station='"+locTow+"' then '"+posTow+"' when X.station='"+locAde+"' then '"+posAde+"' when X.station='"+locBris+"' then '"+posBris+"' when X.station='"+locMel+"' then '"+posMel+"' else '0' END,case when X.station='"+locTow+"' then '"+currDateNine+"' else '"+currDateTen+"' END, substring((((X.c1+X.c2)/2)),0,4), case when (((X.c1+X.c2)/2)) >= 30 then 'Sunny' when (((X.c1+X.c2)/2)) <= 0 then 'Snowy' when (((X.c1+X.c2)/2)) >=20 then 'Cloudy' else 'Rainy' end,(X.c3+950),case when (X.c4)<50 then (X.c4+50) else (X.c4+0) end from (select station,((AVG(maxt)-32)/1.8),((AVG(mint)-32)/1.8),max(mxspd),max(prcp)  from "+weatherDataTable+" where months='@' and days='@@' group by station) X"
  //val calcQuery:String="select X.station, case when X.station='Sydney' then '-33.86,151.21,39' when X.station='Townsville' then '-19.25,146.81,16' when X.station='Adelaide' then '-34.92,138.62,48' when X.station='Brisbane' then '-27.46,153.02,28' when X.station='Melbourne' then '-37.83,144.98,7' else '0' END,case when X.station='Townsville' then '2017-06-16 20:00:21' else '2017-06-16 20:30:21' END from (select station,round(AVG(maxt)-32,1),AVG(mint)-32  from weatherData where months='06' and days='16' group by station) X"
  val repString1:String="@"
  val repString2:String="@@"
}